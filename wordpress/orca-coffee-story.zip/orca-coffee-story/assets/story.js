/* Orca Coffee Story — scroll-step video storytelling. One scroll gesture = one step. */
(() => {
  'use strict';
  const roots = [...document.querySelectorAll('.orca-story')];
  if (!roots.length) return;

  const reduced = matchMedia('(prefers-reduced-motion: reduce)').matches;
  const fa = n => String(n).replace(/\d/g, d => '۰۱۲۳۴۵۶۷۸۹'[d]);
  const mkVideo = () => { const v = document.createElement('video'); v.muted = true; v.playsInline = true; v.preload = 'auto'; v.setAttribute('playsinline', ''); v.setAttribute('muted', ''); return v; };

  // whole file into memory -> instant, stutter-free seeks
  async function loadInto(url, v, onProgress) {
    try {
      const r = await fetch(url);
      if (!r.ok || !r.body) throw new Error('fetch');
      const total = +r.headers.get('content-length') || 4e6, rd = r.body.getReader(), parts = []; let got = 0;
      for (;;) { const { done, value } = await rd.read(); if (done) break; parts.push(value); got += value.length; onProgress && onProgress(Math.min(1, got / total)); }
      v.src = URL.createObjectURL(new Blob(parts, { type: 'video/mp4' }));
    } catch (e) { v.src = url; }
    await new Promise(res => { if (v.readyState >= 2) res(); else { v.addEventListener('loadeddata', res, { once: true }); v.load(); } });
  }

  class Story {
    constructor(el) {
      this.el = el;
      this.REST = el.dataset.rest.split(',').map(Number);
      this.LAST = this.REST.length - 1;
      this.D = 10.0;
      this.IA = +el.dataset.idle; this.IB = this.REST[this.LAST];
      this.names = el.dataset.names.split(',');
      this.src = el.dataset.src;
      this.offset = +el.dataset.offset || 0;
      el.style.setProperty('--os-offset', this.offset + 'px');
      this.canvas = el.querySelector('canvas'); this.ctx = this.canvas.getContext('2d');
      this.chapters = [...el.querySelectorAll('.os-chapter')];
      this.idx = [...el.querySelectorAll('.os-index button')];
      this.counter = el.querySelector('.os-counter'); this.hint = el.querySelector('.os-hint'); this.live = el.querySelector('.os-live');
      this.prevBtn = el.querySelector('.os-prev'); this.nextBtn = el.querySelector('.os-next');
      this.bar = el.querySelector('.os-loading i');
      this.step = 0; this.animating = false; this.ready = false; this.loading = false; this.dirty = true; this.visible = false;
      this.fwd = mkVideo(); this.rev = mkVideo(); this.active = null; this.seg = null; this.box = { w: 0 };
      this.poster = new Image(); this.poster.onload = () => { this.dirty = true; }; this.poster.src = this.src + '-poster.jpg';
      this.idling = false; this.idleTimer = 0;
      this.prevBtn.addEventListener('click', () => this.go(this.step - 1));
      this.nextBtn.addEventListener('click', () => { if (this.step < this.LAST) this.go(this.step + 1); else page.continueAfter(this); });
      this.idx.forEach(b => b.addEventListener('click', () => this.go(+b.dataset.go)));
      new IntersectionObserver(([e]) => { this.visible = e.isIntersecting; if (this.visible) { this.dirty = true; this.scheduleIdle(); } else this.stopIdle(); }).observe(el);
      // start downloading when the story gets close to the screen
      new IntersectionObserver(([e], o) => { if (e.isIntersecting) { o.disconnect(); this.load(); } }, { rootMargin: '150% 0px' }).observe(el);
      this.resize(); this.ui();
    }
    async load() {
      if (this.loading) return; this.loading = true;
      const p = [0, 0], upd = () => { if (this.bar) this.bar.style.transform = `scaleX(${(p[0] + p[1]) / 2})`; };
      await Promise.all([loadInto(this.src + '-fwd.mp4', this.fwd, x => { p[0] = x; upd(); }), loadInto(this.src + '-rev.mp4', this.rev, x => { p[1] = x; upd(); })]);
      this.ready = true; this.el.classList.add('os-ready'); this.active = this.fwd;
      this.fwd.currentTime = this.REST[this.step]; this.rev.currentTime = Math.min(this.D - .001, this.D - this.REST[this.step]);
      this.fwd.addEventListener('seeked', () => { this.dirty = true; }, { once: true });
      this.dirty = true; this.box = { w: 0 };
      this.scheduleIdle();
    }
    top() { return this.el.getBoundingClientRect().top + scrollY - this.offset; }
    isAligned() { return Math.abs(this.el.getBoundingClientRect().top - this.offset) < 2; }
    fwdTime() { return this.active === this.rev ? this.D - this.rev.currentTime : this.fwd.currentTime; }
    canStep(dir) { return dir > 0 ? this.step < this.LAST : this.step > 0; }
    stepBy(dir) { this.go(this.step + dir); }

    resize() { const dpr = Math.min(devicePixelRatio || 1, 2); this.canvas.width = this.canvas.clientWidth * dpr; this.canvas.height = this.canvas.clientHeight * dpr; this.box = { w: 0 }; this.dirty = true; }
    layout(sw, sh) {
      const cw = this.canvas.width, ch = this.canvas.height;
      const contain = Math.min(cw / sw, ch / sh), cover = Math.max(cw / sw, ch / sh), portrait = cw < ch;
      const s = portrait ? Math.min(cover, contain * 1.55) : Math.min(cover, contain * 0.92);
      const w = sw * s, h = sh * s;
      this.box = { x: portrait ? (cw - w) * 0.62 : (cw - w) * (cw / ch > 1.5 ? 0.92 : 0.5), y: portrait ? ch * 0.07 : (ch - h) / 2, w, h };
    }
    draw() {
      const src = this.ready ? this.active : this.poster;
      const sw = this.ready ? src.videoWidth : this.poster.naturalWidth, sh = this.ready ? src.videoHeight : this.poster.naturalHeight;
      if (!sw) return;
      if (!this.box.w) this.layout(sw, sh);
      const { x, y, w, h } = this.box, c = this.ctx;
      c.fillStyle = '#000'; c.fillRect(0, 0, this.canvas.width, this.canvas.height);
      c.drawImage(src, x, y, w, h);
      const f = Math.min(w, h) * 0.16;   // feather the edges into black
      const edge = (x0, y0, x1, y1, rx, ry, rw, rh) => { const g = c.createLinearGradient(x0, y0, x1, y1); g.addColorStop(0, '#000'); g.addColorStop(1, 'rgba(0,0,0,0)'); c.fillStyle = g; c.fillRect(rx, ry, rw, rh); };
      edge(x, 0, x + f, 0, x - 1, y, f + 1, h);
      edge(x + w, 0, x + w - f, 0, x + w - f, y, f + 1, h);
      edge(0, y, 0, y + f, x, y - 1, w, f + 1);
      edge(0, y + h, 0, y + h - f, x, y + h - f, w, f + 1);
    }

    playSeg(forward, fromT, toT, rate, onEnd) {
      const v = forward ? this.fwd : this.rev, D = this.D;
      const start = forward ? fromT : D - fromT, end = forward ? toT : D - toT;
      const begin = () => { this.active = v; v.playbackRate = rate; this.seg = { v, end, onEnd }; const p = v.play(); if (p && p.catch) p.catch(() => {}); };
      if (Math.abs(v.currentTime - start) > 0.02) { v.addEventListener('seeked', begin, { once: true }); v.currentTime = start; } else begin();
    }
    checkSeg() {
      if (!this.seg) return;
      const { v, end, onEnd } = this.seg;
      if (v.currentTime >= end - 0.008 || v.ended) { v.pause(); this.seg = null; onEnd && onEnd(); }
    }
    stopAll() { this.seg = null; this.fwd.pause(); this.rev.pause(); }
    park() { const t = this.fwdTime(); if (this.active === this.fwd) this.rev.currentTime = Math.min(this.D - .001, this.D - t); else this.fwd.currentTime = Math.max(0, t); }
    jumpTo(to) {
      this.stopIdle(); this.stopAll(); this.animating = false; this.step = to; this.ui();
      if (!this.ready) return;
      this.active = this.fwd; this.fwd.currentTime = this.REST[to];
      this.fwd.addEventListener('seeked', () => { this.dirty = true; this.park(); this.scheduleIdle(); }, { once: true });
    }
    go(to) {
      if (!this.ready || this.animating || to < 0 || to > this.LAST || to === this.step) return;
      this.stopIdle();
      const from = this.fwdTime(), target = this.REST[to], forward = to > this.step, len = Math.abs(target - from), jump = Math.abs(to - this.step) > 1;
      this.step = to; this.ui();
      if (reduced) { this.jumpTo(to); return; }
      // playback speed: 0.7–0.85x of the 60fps footage (smooth, a little slower than real time)
      const rate = jump ? Math.max(.9, len / 3) : Math.min(.85, Math.max(.7, len / 2));
      this.animating = true;
      this.playSeg(forward, from, target, rate, () => { this.animating = false; page.lastEnd = performance.now(); this.park(); this.scheduleIdle(); });
    }
    ui() {
      const st = this.step;
      this.chapters.forEach((c, i) => { c.classList.toggle('os-on', i === st); c.toggleAttribute('inert', i !== st); });
      this.idx.forEach((b, i) => i + 1 === st ? b.setAttribute('aria-current', 'step') : b.removeAttribute('aria-current'));
      this.counter.innerHTML = st ? `<b>0${st}</b> / 0${this.LAST}` : '';
      if (this.hint) this.hint.style.opacity = st ? 0 : 1;
      this.prevBtn.disabled = st === 0;
      this.nextBtn.setAttribute('aria-label', st === this.LAST ? 'ادامه‌ی صفحه' : 'مرحله‌ی بعد');
      this.live.textContent = `مرحله‌ی ${fa(st)} از ${fa(this.LAST)}: ${this.names[st]}`;
    }
    bars() {
      const t = this.ready ? this.fwdTime() : 0, R = this.REST;
      this.idx.forEach((b, i) => { b.querySelector('i').style.transform = `scaleX(${Math.min(1, Math.max(0, (t - R[i] - .03) / (R[i + 1] - R[i] - .03)))})`; });
    }
    scheduleIdle() { clearTimeout(this.idleTimer); if (this.step === this.LAST && this.ready && this.visible && !reduced && !this.animating) this.idleTimer = setTimeout(() => { this.idling = true; this.idleLeg(false); }, 900); }
    idleLeg(forward) {
      if (!this.idling || this.step !== this.LAST) return;
      this.playSeg(forward, this.fwdTime(), forward ? this.IB : this.IA, .35, () => { this.park(); this.idleTimer = setTimeout(() => this.idleLeg(!forward), 120); });
    }
    stopIdle() { this.idling = false; clearTimeout(this.idleTimer); if (this.seg && !this.animating) { this.stopAll(); this.park(); } }
    frame(tx, ty) {
      this.checkSeg();
      if (!this.visible) return;
      if (this.seg || this.dirty) { this.draw(); this.dirty = false; }
      this.bars();
      this.canvas.style.transform = `rotateY(${tx * -3}deg) rotateX(${ty * 2.5}deg) translate3d(${tx * -10}px,${ty * -8}px,0)`;
    }
  }

  const stories = roots.map(el => new Story(el));
  addEventListener('resize', () => stories.forEach(s => s.resize()));

  let lastY = scrollY, swallow = false, jumpTimer = 0;
  const page = {
    lastEnd: 0, jumping: false,
    aligned() { return stories.find(s => s.isAligned()); },
    release(ms) { page.jumping = true; clearTimeout(jumpTimer); jumpTimer = setTimeout(() => { page.jumping = false; lastY = scrollY; }, ms); },
    continueAfter(s) {
      const y = s.el.getBoundingClientRect().bottom + scrollY - s.offset;
      page.release(1600);
      scrollTo({ top: y, behavior: reduced ? 'auto' : 'smooth' });
    }
  };

  // Guard: any scroll (wheel, touch momentum, keys, scrollbar) that would pass an unfinished story stops at it.
  addEventListener('scroll', () => {
    const y = scrollY;
    if (!page.jumping) for (const s of stories) {
      if (!s.ready) continue;
      const top = s.top();
      if ((y > lastY && lastY <= top + 1 && y > top + 1 && s.step < s.LAST) || (y < lastY && lastY >= top - 1 && y < top - 1 && s.step > 0)) {
        scrollTo({ top, behavior: 'instant' }); swallow = true; break;
      }
    }
    lastY = scrollY;
  }, { passive: true });

  let lastWheel = 0, lastAbs = 0;
  addEventListener('wheel', e => {
    const now = performance.now(), abs = Math.abs(e.deltaY);
    const fresh = now - lastWheel > 260 || (abs > lastAbs * 2 && abs > 30 && now - page.lastEnd > 300);
    lastWheel = now; lastAbs = abs;
    if (fresh) swallow = false;
    if (page.jumping || e.ctrlKey) return;
    const s = page.aligned();
    if (!s) { if (swallow) e.preventDefault(); return; }
    if (s.animating || swallow) { e.preventDefault(); return; }
    if (abs < 2) return;
    const dir = Math.sign(e.deltaY);
    if (s.canStep(dir)) { e.preventDefault(); s.stepBy(dir); swallow = true; }
  }, { passive: false });

  let ty0 = null, used = false;
  addEventListener('touchstart', e => { ty0 = e.touches[0].clientY; used = false; }, { passive: true });
  addEventListener('touchmove', e => {
    if (ty0 === null) return;
    const s = page.aligned(); if (!s) return;
    const dy = ty0 - e.touches[0].clientY, dir = Math.sign(dy);
    if ((s.animating || s.canStep(dir)) && e.cancelable) e.preventDefault();
    if (!used && !s.animating && s.canStep(dir) && Math.abs(dy) > 40) { used = true; s.stepBy(dir); }
  }, { passive: false });
  addEventListener('touchend', () => { ty0 = null; }, { passive: true });

  addEventListener('keydown', e => {
    const t = e.target;
    if (t && (t.isContentEditable || /^(INPUT|TEXTAREA|SELECT)$/.test(t.tagName))) return;
    const dir = ['ArrowDown', 'PageDown', ' '].includes(e.key) ? 1 : ['ArrowUp', 'PageUp'].includes(e.key) ? -1 : 0;
    if (!dir) return;
    const s = page.aligned(); if (!s) return;
    if (s.animating || s.canStep(dir)) { e.preventDefault(); if (!s.animating && !e.repeat) s.stepBy(dir); }
  });

  // The theme's own in-page menu links (#products etc.) must not be stopped by the guard.
  document.addEventListener('click', e => {
    const a = e.target.closest && e.target.closest('a[href*="#"]');
    if (!a || a.closest('.orca-story')) return;
    let target = null;
    try { const u = new URL(a.href, location.href); if (u.pathname === location.pathname && u.hash.length > 1) target = document.getElementById(decodeURIComponent(u.hash.slice(1))); } catch (err) { /* ignore */ }
    if (!target) return;
    const y = target.getBoundingClientRect().top + scrollY;
    stories.forEach(s => { if (y > s.top() + 2 && s.step < s.LAST) s.jumpTo(s.LAST); });
    page.release(2000);
  }, true);

  let mx = 0, my = 0, tx = 0, ty = 0;
  if (!reduced) addEventListener('pointermove', e => { mx = e.clientX / innerWidth - .5; my = e.clientY / innerHeight - .5; }, { passive: true });
  (function tick() {
    tx += (mx - tx) * .04; ty += (my - ty) * .04;
    stories.forEach(s => s.frame(tx, ty));
    requestAnimationFrame(tick);
  })();
})();
