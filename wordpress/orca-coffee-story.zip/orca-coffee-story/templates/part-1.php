<?php if ( ! defined( 'ABSPATH' ) ) { exit; } ?>
<section class="orca-story" dir="rtl" aria-label="از مزرعه تا رُست"
  data-src="<?php echo esc_url( $video . 's1' ); ?>" data-rest="0,2.9,4.92,7.42,9.97" data-idle="9.0"
  data-names="معرفی,مزرعه,میوه,رُستری,رُست" data-offset="<?php echo esc_attr( $offset ); ?>">
  <div class="os-rig"><canvas aria-hidden="true"></canvas></div>
  <div class="os-shade"></div>
  <ol class="os-index" aria-label="مراحل">
    <li><button type="button" data-go="1"><span class="os-ln"><i></i></span><span class="os-nm">مزرعه</span></button></li>
    <li><button type="button" data-go="2"><span class="os-ln"><i></i></span><span class="os-nm">میوه</span></button></li>
    <li><button type="button" data-go="3"><span class="os-ln"><i></i></span><span class="os-nm">رُستری</span></button></li>
    <li><button type="button" data-go="4"><span class="os-ln"><i></i></span><span class="os-nm">رُست</span></button></li>
  </ol>
  <article class="os-chapter os-on">
    <div class="os-kicker"><span class="os-latin">Farm to Cup</span></div>
    <h2 class="os-hero"><?php echo esc_html( $a['title'] ); ?><small>از مزرعه تا فنجان</small></h2>
    <p>داستان هر فنجان ما از دامنه‌های مه‌گرفته‌ی مزرعه شروع می‌شود. اسکرول کنید و قدم‌به‌قدم همراه دانه بیایید.</p>
  </article>
  <article class="os-chapter">
    <div class="os-kicker">مرحله‌ی یک <span class="os-latin">The Farm</span></div>
    <h2>مزرعه‌هایی در ارتفاع و مه صبحگاهی</h2>
    <p>بوته‌های قهوه در شیب کوهستان، آرام زیر نور صبح رشد می‌کنند و میوه‌های قرمز و رسیده دست‌چین می‌شوند.</p>
    <div class="os-spec"><div><b>۱۸۰۰ متر</b><span>ارتفاع مزرعه</span></div><div><b>دست‌چین</b><span>برداشت میوه</span></div></div>
  </article>
  <article class="os-chapter">
    <div class="os-kicker">مرحله‌ی دو <span class="os-latin">The Cherry</span></div>
    <h2>در دل هر میوه، دو دانه‌ی سبز</h2>
    <p>پوست قرمز که باز می‌شود، دو دانه‌ی سبز و خام از دل میوه بیرون می‌آیند؛ همان چیزی که بعداً قهوه می‌شود.</p>
    <div class="os-spec"><div><b>۲ دانه</b><span>در هر میوه</span></div><div><b>۱۰۰٪</b><span>عربیکا</span></div></div>
  </article>
  <article class="os-chapter">
    <div class="os-kicker">مرحله‌ی سه <span class="os-latin">The Roastery</span></div>
    <h2>دانه‌ی سبز به کارگاه رُست می‌رسد</h2>
    <p>گونی‌های دانه‌ی سبز در کارگاه رُست باز می‌شوند و در دسته‌های کوچک داخل دستگاه رُست می‌ریزند.</p>
    <div class="os-spec"><div><b>هفتگی</b><span>رُست تازه</span></div><div><b>دسته‌های کوچک</b><span>کنترل کیفیت</span></div></div>
  </article>
  <article class="os-chapter">
    <div class="os-kicker">مرحله‌ی چهار <span class="os-latin">The Roast</span></div>
    <h2>از سبز تا قهوه‌ای براق</h2>
    <p>درون درام چرخان، دانه‌ها آرام‌آرام رنگ می‌گیرند، روغن طبیعی‌شان بالا می‌آید و عطر قهوه بلند می‌شود.</p>
    <div class="os-spec"><div><b>۲۱۰°</b><span>دمای رُست</span></div><div><b>۱۲ دقیقه</b><span>زمان رُست</span></div></div>
    <a class="os-btn" href="<?php echo esc_url( $a['cta_link'] ); ?>"><?php echo esc_html( $a['cta_text'] ); ?></a>
  </article>
  <div class="os-hint" aria-hidden="true"><span class="os-mouse"></span><span>اسکرول کنید</span></div>
  <div class="os-controls">
    <div class="os-counter" aria-hidden="true"></div>
    <div class="os-navbtns">
      <button type="button" class="os-round os-prev" aria-label="مرحله‌ی قبل"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M12 20V4M5 11l7-7 7 7"/></svg></button>
      <button type="button" class="os-round os-next" aria-label="مرحله‌ی بعد"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M12 4v16M5 13l7 7 7-7"/></svg></button>
    </div>
  </div>
  <div class="os-loading" aria-hidden="true"><i></i></div>
  <p class="os-sr os-live" aria-live="polite"></p>
</section>
