<?php if ( ! defined( 'ABSPATH' ) ) { exit; } ?>
<section class="orca-story" dir="rtl" aria-label="از دانه تا فنجان"
  data-src="<?php echo esc_url( $video . 's2' ); ?>" data-rest="0,2.45,4.92,6.95,8.4,9.97" data-idle="9.0"
  data-names="معرفی,خنک‌سازی,آسیاب,پودر,عصاره,کرما" data-offset="<?php echo esc_attr( $offset ); ?>">
  <div class="os-rig"><canvas aria-hidden="true"></canvas></div>
  <div class="os-shade"></div>
  <ol class="os-index" aria-label="مراحل">
    <li><button type="button" data-go="1"><span class="os-ln"><i></i></span><span class="os-nm">خنک‌سازی</span></button></li>
    <li><button type="button" data-go="2"><span class="os-ln"><i></i></span><span class="os-nm">آسیاب</span></button></li>
    <li><button type="button" data-go="3"><span class="os-ln"><i></i></span><span class="os-nm">پودر</span></button></li>
    <li><button type="button" data-go="4"><span class="os-ln"><i></i></span><span class="os-nm">عصاره</span></button></li>
    <li><button type="button" data-go="5"><span class="os-ln"><i></i></span><span class="os-nm">کرما</span></button></li>
  </ol>
  <article class="os-chapter os-on">
    <div class="os-kicker">بخش دوم <span class="os-latin">The Brew</span></div>
    <h2>از دانه تا فنجان<small>دم‌آوری اسپرسو</small></h2>
    <p>دانه‌ها رُست شدند؛ حالا نوبت ساختن یک شات اسپرسو با کرمای غلیظ است. ادامه دهید.</p>
  </article>
  <article class="os-chapter">
    <div class="os-kicker">مرحله‌ی یک <span class="os-latin">The Cooling</span></div>
    <h2>دانه‌های داغ در سینی خنک می‌شوند</h2>
    <p>بازوهای فلزی دانه‌های تازه‌رُست را هم می‌زنند تا سریع خنک شوند و عطرشان حفظ شود.</p>
    <div class="os-spec"><div><b>۴ دقیقه</b><span>خنک‌سازی</span></div><div><b>۷ روز</b><span>استراحت دانه</span></div></div>
  </article>
  <article class="os-chapter">
    <div class="os-kicker">مرحله‌ی دو <span class="os-latin">The Grinder</span></div>
    <h2>درست لحظه‌ی سفارش، به آسیاب</h2>
    <p>دانه‌ها داخل مخزن آسیاب می‌ریزند؛ هیچ قهوه‌ای از قبل آسیاب نمی‌شود.</p>
    <div class="os-spec"><div><b>۱۸ گرم</b><span>دوز هر شات</span></div><div><b>تازه</b><span>آسیاب لحظه‌ای</span></div></div>
  </article>
  <article class="os-chapter">
    <div class="os-kicker">مرحله‌ی سه <span class="os-latin">The Grounds</span></div>
    <h2>پودری ریز، تازه و معطر</h2>
    <p>پودر یکدست مستقیم داخل پرتافیلتر می‌ریزد و عطرش کل فضا را پر می‌کند.</p>
    <div class="os-spec"><div><b>یکدست</b><span>اندازه‌ی ذرات</span></div><div><b>معطر</b><span>بدون انتظار</span></div></div>
  </article>
  <article class="os-chapter">
    <div class="os-kicker">مرحله‌ی چهار <span class="os-latin">The Shot</span></div>
    <h2>عصاره‌ای غلیظ و عسلی</h2>
    <p>با فشار ۹ بار، عصاره مثل عسل گرم از دستگاه سرازیر می‌شود.</p>
    <div class="os-spec"><div><b>۹ بار</b><span>فشار</span></div><div><b>۹۳°</b><span>دمای آب</span></div></div>
  </article>
  <article class="os-chapter">
    <div class="os-kicker">مرحله‌ی پنج <span class="os-latin">The Crema</span></div>
    <h2>کرمایی ضخیم و طلایی</h2>
    <p>لایه‌ای پرحجم و فندقی روی فنجان می‌نشیند و بخارش بالا می‌رود. حالا نوبت شماست.</p>
    <a class="os-btn" href="<?php echo esc_url( $a['cta_link'] ); ?>"><?php echo esc_html( $a['cta_text'] ); ?></a>
  </article>
  <div class="os-controls">
    <div class="os-counter" aria-hidden="true"></div>
    <div class="os-navbtns">
      <button type="button" class="os-round os-prev" aria-label="مرحله‌ی قبل"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M12 20V4M5 11l7-7 7 7"/></svg></button>
      <button type="button" class="os-round os-next" aria-label="مرحله‌ی بعد"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M12 4v16M5 13l7 7 7-7"/></svg></button>
    </div>
  </div>
  <div class="os-loading" aria-hidden="true"><i></i></div>
  <p class="os-sr os-live" aria-live="polite"></p>
</section>
