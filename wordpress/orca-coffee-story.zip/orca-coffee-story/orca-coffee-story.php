<?php
/**
 * Plugin Name:       Orca Coffee Story
 * Description:       داستان اسکرولی ویدیویی «از مزرعه تا فنجان» برای صفحه‌ی اصلی. شورتکدها: [orca_story part="1"] و [orca_story part="2"]
 * Version:           1.0.1
 * Requires at least: 5.8
 * Requires PHP:      7.2
 * Author:            Orca Coffee
 * License:           GPL-2.0-or-later
 * Text Domain:       orca-coffee-story
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'ORCA_STORY_VERSION', '1.0.1' );

add_action( 'wp_enqueue_scripts', function () {
	wp_register_style( 'orca-story', plugins_url( 'assets/story.css', __FILE__ ), array(), ORCA_STORY_VERSION );
	wp_register_script( 'orca-story', plugins_url( 'assets/story.js', __FILE__ ), array(), ORCA_STORY_VERSION, true );
} );

/**
 * [orca_story part="1"]  — از مزرعه تا رُست
 * [orca_story part="2"]  — از دانه تا فنجان
 *
 * Optional attributes:
 *   title     Brand title shown on the first screen of part 1 (default: اورکا)
 *   cta_text  Button text on the last step
 *   cta_link  Button link on the last step (default: /shop/)
 *   offset    Height in px of a fixed/sticky theme header, so the story stops just below it (default: 0)
 */
add_shortcode( 'orca_story', function ( $atts ) {
	$part = ( isset( $atts['part'] ) && '2' === (string) $atts['part'] ) ? 2 : 1;
	$a    = shortcode_atts(
		array(
			'part'     => '1',
			'title'    => 'اورکا',
			'cta_text' => 1 === $part ? 'مشاهده‌ی محصولات' : 'سفارش همین اسپرسو',
			'cta_link' => '/shop/',
			'offset'   => '0',
		),
		$atts,
		'orca_story'
	);

	wp_enqueue_style( 'orca-story' );
	wp_enqueue_script( 'orca-story' );

	$video  = plugins_url( 'assets/video/', __FILE__ );
	$offset = max( 0, (int) $a['offset'] );

	ob_start();
	include __DIR__ . '/templates/part-' . $part . '.php';
	return ob_get_clean();
} );
